import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { ConfirmPasswordValidator } from './password-match/password-match';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  name = '';
  email = '';
  mobile = '';

  isSubmitted =  false;

  chatForm : FormGroup;

  constructor(private fb : FormBuilder) {}

  ngOnInit() {

    // this.chatForm = this.fb.group({

    //   'name': new FormControl(null, [ 
    //     Validators.required, 
    //     Validators.minLength(2),
    //     Validators.pattern('[a-zA-Z ]*')]),

    //   'email': new FormControl(null, [ 
    //     Validators.required, 
    //     Validators.email]),

    //   'mobile': new FormControl(null, [ 
    //     Validators.required, 
    //     Validators.minLength(10), 
    //     Validators.maxLength(10), 
    //     Validators.pattern('[0-9]*')]),

    //   'password': new FormControl(null, [ 
    //     Validators.required, 
    //     Validators.minLength(8), 
    //     Validators.maxLength(8), 
    //     Validators.pattern('[0-9a-z!@#$%^&*]')]),

    //    'confirmpassword': new FormControl(null, [
    //      Validators.required
    //    ])
    // }, { validator: ConfirmPasswordValidator.MatchPassword });

    this.chatForm = new FormGroup({

      'name': new FormControl(null, [ 
        Validators.required, 
        Validators.minLength(2),
        Validators.pattern('[a-zA-Z ]*')]),

      'email': new FormControl(null, [ 
        Validators.required, 
        Validators.email]),

      'mobile': new FormControl(null, [ 
        Validators.required, 
        Validators.minLength(10), 
        Validators.maxLength(10), 
        Validators.pattern('[0-9]*')]),

      'password': new FormControl(null, [ 
        Validators.required, 
        Validators.minLength(8), 
        Validators.maxLength(8), 
        Validators.pattern('[a-z0-9]*')]),

      'confirmpassword' : new FormControl(null, [
        Validators.required])
      });

  }

  onSubmit(){

    this.name = this.chatForm.value.name;
    this.email = this.chatForm.value.email;
    this.mobile = this.chatForm.value.mobile;

    console.log(this.chatForm);
    this.isSubmitted = true;
    this.chatForm.reset();

  }

}
